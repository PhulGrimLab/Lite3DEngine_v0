#pragma once

void printHello();